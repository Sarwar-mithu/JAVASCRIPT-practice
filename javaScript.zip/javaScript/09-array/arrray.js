/*
var names = new Array();
names[0] = "Sarwar";
names[1] = "Aayash";
names[2] = "Salman";
names[3] = "Mehedi";
names[4] = "Taher";
names[5] = "Sajada";
names[6] = "Mishu";

document.write(names);
*/


var names = [" Abbu ", " ammu "," vaiya "," vabhi "];

document.write(" Total Array Length : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");

//function method 
names.push(" Chotto vai ");  //push -> insert index
document.write("After adding Length : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");



names.pop(names[4]);    //pop -> Delate index
document.write("Delate Array : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");


names.shift();     //shift method starting delate
document.write("Starting  Delate Array : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");


names.unshift(" Abu Jafor Mehedi ");     //unshift method starting Adding 
document.write("Starting  Delate Array : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");



names.splice(2,0," Salman "," Mithu ");     // element adding(2 num index now)
document.write("Adding Elements in Now  : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");



names.splice(4,6);     // element remove(2 num index now),delate last elements
document.write("Remove Elements in Now  : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");



var newArray = names.slice(2);  //slice new array thory korbe (delate).punari abar ager arrya te pere jabe
document.write("Delate array : "+newArray.length+"</br>");
document.write(newArray +"</br>");
document.write("Befor array  : "+names.length +"</br>");
document.write(names +"</br>");
document.write("</br>");



var sortedNames = names.sort();    //Alphabet sorted
document.write("Sorten By Names : "+names +"</br>");
document.write("</br>");

var sortedNames = names.sort();    //Reverse sorted
names.reverse();
document.write("Sorten By Names : "+names +"</br>");
document.write("</br>");



var numbers = [20,5,25,15,45,1];
document.write(numbers +"<br>");
numbers.sort(function(a,b){     //number sorted in process
    return a-b;

});
document.writeln("After Sorted By : "+numbers);
document.write("</br>");



var country1 = ["Bangadesh ", "Nepal "];
var country2 = ["Pakistan ", "Bhutan "];

var country = country1.concat(country2);   // concat -> adding the names
document.write("Concat : "+country );



document.write("</br> </br> </br>");


