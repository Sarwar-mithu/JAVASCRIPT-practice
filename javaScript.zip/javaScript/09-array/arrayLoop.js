document.write("Array Loop Start Here "+"<br><br/>");


var num = new Array();

for(var i = 0; i <= 5; i++){
    num[i]= parseInt(prompt("Enter a number : "));
}


var sum = 0;

for(var i = 0; i <= 5; i++){
    document.write(num[i] +" ");
    sum = sum + num[i];
}
document.write("<br>");
document.write("Sum is : "+sum);