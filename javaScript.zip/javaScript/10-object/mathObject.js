document.write("<h1>Math Object Start Here</h1>");


var square = parseInt(Math.sqrt(25));
document.write("Square : "+square);
document.write(" </br>");


var absoulate = Math.abs(-9);
document.write("Absoulate value : "+absoulate);
document.write(" </br>");

var power = Math.pow(2,3);
document.write("Two the power Three : "+power);
document.write(" </br>");

var formula = Math.sin(2);
document.write("Sin : "+formula);
document.write(" </br>");


var bottom = Math.floor(2.67);
document.write("Orginal Value : "+bottom);
document.write(" </br>");

var uper = Math.ceil(2.67);
document.write("Orginal Value : "+uper);
document.write(" </br>");

var rou = Math.round(8.67);
document.write("Round Figure : "+rou);
document.write(" </br>");


var maximum = Math.max(30,10,5,20);
document.write("Maximum number : "+maximum);
document.write(" </br>");

var minimum = Math.min(30,10,5,20);
document.write("Minimum number : "+minimum);
document.write(" </br>");



var rand = Math.floor(Math.random()*5) + 10;   // Math.random -> value sodhu change hotei thakbe
document.write("Random Number : "+rand);
document.write(" </br>");

