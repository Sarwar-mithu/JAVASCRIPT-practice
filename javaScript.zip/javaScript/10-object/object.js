//How to create an object
//How to print the value of an object
//Adding a Constructor
//Adding function inside a construct


function Student(name,age,cgpa,lang){
    this.name = name;
    this.age = age;
    this.cgpa = cgpa;
    this.lang = lang;


    this.displayInformation = function(){
        document.write("Name : "+this.name + "<br>");
        document.write("Age : "+this.age + "<br>");
        document.write("CGPA : "+this.cgpa+ "<br>");
        document.write("Language : "+this.lang+ "<br>");
        document.write("<br> </br>");

    }
}


var student1 = new Student("Sarwar mithu", 25, 3.40,["Bangla","English"]);
student1.displayInformation();


var student2 = new Student("Abu Salman", 22, 3.90,["Bangla","English"]);
student2.displayInformation();


var student3 = new Student("Abu Zafor Mehedi", 30, 3.40,["Bangla","English"]);
student3.displayInformation();