/*var num = "90";

num = parseInt(num)

// num = toString(num);

console.log(typeof(num));
*/


/*var number = 2.5678;

console.log(number.toFixed(2));

console.log(number.toPrecision(2));
*/

console.log(Number("12"))


console.log(typeof(Number("12")))


console.log(Number(      12.44   ))



console.log(Number(true))

console.log(Number(false))
