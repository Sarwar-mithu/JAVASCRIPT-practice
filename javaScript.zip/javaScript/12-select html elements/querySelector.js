//start form querySelector

document.querySelector("#pid").innerHTML = "Change for (#)Id ";
document.querySelector(".cls").innerHTML = "Change for (.)cls ";
document.querySelector("h4").innerHTML = "change for tagName";


//querySelector basic program
document.querySelector("a").innerHTML = "New text";

document.querySelector("li a").innerHTML = "Media(parents->child)";

document.querySelector(".my-div a").innerHTML = "sequence div -> a";



//querySelectorAll 

document.querySelectorAll("p")[1].innerHTML = "change for paragraph-1";