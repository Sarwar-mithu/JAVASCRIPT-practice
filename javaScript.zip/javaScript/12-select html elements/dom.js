
//getElementById

document.getElementById("heading1").innerHTML = "Sarwar mithu";

//chile ekai kaj amra variabler moddhome dekate pari
var p_tag = document.getElementById("para");
p_tag.innerHTML = "Hello mithu";


var head = document.getElementById("heading2");
head.innerHTML = "good by" ;

document.write("<br> </br>");





// start from getElementsByTagName  querySelector

document.getElementsByTagName("h2")[0].innerHTML = "Hi-1"; //index number bole deoa lagbe
document.getElementsByTagName("h2")[1].innerHTML = "Hi-2";



//sart form getElementsByClassName

document.getElementsByClassName("para1")[0].innerHTML = "cls name 1";
document.getElementsByClassName("para1")[1].innerHTML = "with index cls 2";

document.write("<br> </br>");




