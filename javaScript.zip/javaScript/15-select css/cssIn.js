// basic css style in js start

function addStyle(){
    var myVar = document.querySelector("#para-1");
    /*
    myVar.style.color = "red";            //individual style property use kora
    myVar.style.fontSize = "3rem";
    myVar.style.fontWeight = "bold";
    myVar.style.fontStyle = "italic";
    */

    myVar.classList.add("para-style");
}



function removeStyle(){
    var myVar = document.querySelector("#para-1");
    myVar.classList.remove("para-style");
}



// Event Listiener start
/*
 var listien = document.querySelector("button").addEventListener("click",myFunction);


 function myFunction(){
     alert("hello");
 }
 */

 var myListien = document.querySelector("h1");
//click
 myListien.addEventListener("click", function(){
    alert("Thanks for click");
});


//mouseover 
myListien.addEventListener("mouseover", function(){ 
       myListien.classList.add("heading-style");
});
//mouseout
myListien.addEventListener("mouseout",function(){
       myListien.classList.remove("heading-style");
});



// Event Listeners with multiple elements start

for(var i = 0; i < 3;i++){

    
    var listienrMulti = document.querySelectorAll(".myButton")[i];

    listienrMulti.addEventListener("click",function(){
    var text = this.innerHTML;
    document.querySelectorAll("h1")[1].innerHTML = text +" is clicked";
       
});

}


//start from audio add
 

for( var i = 0; i < 3; i++){
    var songs = document.querySelectorAll(".mySong")[i];
        songs.classList.add("addSong");
        songs.addEventListener("click", function(){
        var text = this.innerHTML;
        console.log(text);
        audioPlay(text);
           
    });
       
}

document.addEventListener("keypress", function(event){
    var text = event.key;
    audioPlay(text);

});

function audioPlay(text){
    switch(text){
        case "play 1":
            var audio = new Audio("songs/s1.mp3");
            audio.play();
            break;

        case "play 2":
            var audio = new Audio("songs/s2.mp3");
            audio.play();
            break;

        case "play 3":
            var audio = new Audio("songs/s3.mp3");
            audio.play();
            break;
    }
}


//event start 
document.addEventListener("keypress", function(event){
    var userReminder =  event.key;
    
    document.querySelectorAll("p")[1].innerHTML = "You have pressed : "+userReminder;

});


//text area start
var count = 0;
document.querySelector("textarea").addEventListener("keypress", function(event){
    var totalText = event.key;
    count++;


    document.querySelectorAll("p")[2].innerHTML = "You have pressed : "+count;
});

