//button onclick

function messageInfo(){
    alert("Thanks for click");
}

function messageInfo2(){
    alert("Process Complete");
}



var myVar = document.querySelector("#paraId");
function paragraph(){
     myVar.innerHTML = "You have clicked on paragraph";
}



// add image for button
var pic = document.querySelector("#myPicture");
function addImage1(){
      pic.src = "p1.jpg";
}

function addImage2(){
    pic.src = "p2.jpg";
}
