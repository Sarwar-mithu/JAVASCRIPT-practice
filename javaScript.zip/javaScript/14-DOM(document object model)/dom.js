//creating html element

var heading3 = document.createElement("h1");
var text = document.createTextNode("This is heading 3 add");
heading3.appendChild(text);



 var myDiv = document.getElementById("my-div");
 myDiv.appendChild(heading3);


 //remove html element

 var heading2 = document.getElementsByTagName("h1")[1];

 myDiv.removeChild(heading2);



 //uper creating html element

 var heading0 = document.createElement("h1");
 var text0 = document.createTextNode("Uper elments add");
 heading0.appendChild(text0);

 var heading1 = document.getElementsByTagName("h1")[0];

 myDiv.insertBefore(heading0,heading1);

 document.write("<br> </br>");


 // slider start 

 var photos = ["images/p1.jpg","images/p2.jpg","images/p3.jpg"];
  var imagTag = document.querySelector("img");

  var count = 0;

 function next(){
     count++;

     if(count>=photos.length) {
         count = 0;
         imagTag.src = photos[count];
     }
     else {
         imagTag.src = photos[count];
     }

 }

 function prev(){
     count--;

     if(count < 0){
         count = photos.length-1;
         imagTag.src = photos[count];
     }
     else{
         imagTag.src = photos[count];
     }

 }