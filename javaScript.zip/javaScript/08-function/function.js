//basic format
/*
//creating a function
function sqaure(num){
    var result = num * num;
    document.write("Result = "+result +"<br>");
}

//calling a function 
sqaure(5);
sqaure(6);
sqaure(7);

*/




//add function 

function addition(x,y){
    var result = x + y;
    document.write("Sum is : "+result + "</br>");
}

// sub function 
// how to return function
function subtraction(x,y){
    var result = x - y;
   return result;         // ruturn kore subtraction jabe
}


//calling function 
addition(10,5);
addition(100,5);

document.write("Sub is : "+subtraction(20,8) + "</br>");
document.write("Sub is : "+subtraction(100,80) + "</br>");




