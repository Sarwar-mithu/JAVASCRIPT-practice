var i = 1;

do{
    document.write("Bangladehs" + "</br>")
    i++;
}while(i<=5);
