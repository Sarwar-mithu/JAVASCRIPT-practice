
var num1 = parseInt(prompt("Enter first number : "));
var num2 = parseInt(prompt("Enter second number : "));


var sum = 0;

for(var i = num1; i <= num2; i++){
    sum = sum + i;
}
document.write("Result : "+sum + "<br/>");