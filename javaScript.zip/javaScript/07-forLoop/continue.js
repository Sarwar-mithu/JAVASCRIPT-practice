//Condinue Conditon

for(var i=1; i<=20; i++){
    if(i==10){                // 10 value print korbe na ta chara sob kichu print korbe 
        continue;
    }
    document.write("  "+i);
}