//break condition 

for(var i=1; i<= 100; i++){

    if(i==10){
        break;
    }
    document.write( "  "+ i +"</br>");
}