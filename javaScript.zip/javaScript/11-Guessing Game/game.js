//Guess a number from 1 to 5

var numberOfWon = 0;
var numberOfLost =0;


for(var i =1; i<=5; i++){

    var guessNumber = parseInt(prompt("Enter a number from 1 to 5 : "));

    var ranodomNumber = Math.floor(Math.random()*5) +1;
    if(guessNumber==ranodomNumber){
        document.write("You have won"+"<br>");
        numberOfWon++;
    
    }
    else{
        document.write("You have lost. Random number was "+ranodomNumber+"<br>");
        numberOfLost++;
    }

}

document.write("Number of won : "+numberOfWon+"<br>");
document.write("Number of Lost : "+numberOfLost+"<br>");

