var num = parseInt(prompt("Enter your Number : "));
if(num%2==0){
    document.write(num + " is Even "+"</br>");
}
else if(num%2!==0){
    document.write(num + " is Odd "+"</br>");
}


var num1 = prompt("Enter num1 : ");
var num2 = prompt("Enter num2 : ");
var num3 = prompt("Enter num3 : ");

if(num1>num2 && num1>num3){
    document.write(num1+" = large number"+"</br>");
}
else if(num2>num1 && num2>num3){
    document.write(num2 + " = lagge number" +"</br>");
}
else{
    document.write(num3+ "= large number" +"</br>");
}


var la = prompt("Enter your letter : ");

la = la.toLowerCase();
if(la=="a" || la=="e" || la=="i" || la=="o" || la=="u"){
    document.write(la + " Vowel" +"<br/>");

}
else{
    document.write(la + " Not vowel"+"<br/>");
}

